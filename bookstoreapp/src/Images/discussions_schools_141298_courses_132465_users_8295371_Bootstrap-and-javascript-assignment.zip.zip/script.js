function  valid() {
  var name=/^[A-Za-z]+(\s)+[A-Za-z]/;
  var email=/^(\w+[\-\.])*\w+@(\w+\.)+[A-Za-z]+$/;
  var contact=/^(\d){10,11}$/;
  var msg=/^(\w)+$/;
  var nam=document.getElementById("nm").value;
    if (nam==""){
    alert("Name cannot be blank");
    return false;
    }
    if(!name.test(nam)){
    alert("Name has to be a combination of fname and lname");
    return false;
    }
  var emai=document.getElementById("em").value;
    if(emai==""){
    alert("Email cannot blank");
    return false;
    }
    if (!email.test(emai)){
    alert("Email should have proper validation");
    return false;
    }
  var con=document.getElementById("ct").value;
    if(con==""){
      alert("Contact cannot be blank");
      return false;
    }
    if(!contact.test(con)){
    alert("Contact should be in between 10 to 11");
    return false;
  }

  var msgg=document.getElementById("mg").value;
    if(msgg==""){
      alert("Message cannot be blank");
      return false;
    }
    if(!msg.test(msgg)){
    alert("Message should be in alphanumeric");
    return false;
    }
    
    
}
